<?php
/**
 * Created by PhpStorm.
 * User: simonturesson
 * Date: 2016-11-23
 * Time: 07:52
 */


namespace app;

class MyClass
{
    public $libprop = 'LibClassVar';

    function testFunction()
    {
        echo 'LibClass';
    }
}


?>